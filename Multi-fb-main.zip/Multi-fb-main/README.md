# ✭ MULTI CRACK

<h5 align="left">CARA INSTALL 
SCRIPT:</h5>

download aplikasi termux di sini <a href="https://f-droid.org/repo/com.termux_118.apk">klik disini</a> lalu buka aplikasinya ketikan perintah dibawah ini.


    $pkg update && pkg upgrade
    $pkg install git
    $pkg install python
    $git clone https://github.com/MR-X-HADI/Multi-fb
    $pip install requests
    $pip install bs4
    $pip install rich
    $pip install stdiomask

<h5 align="left">MULAI </h5>

    $ git pull
    $ cd Multi-fb
    $ python Multi.py


## Login Mengunakan
- [x] Cookie 

## Metode Crack
- [x] Mobile 
- [x] MBASIC 
- [x] VALIDATE 
- [x] B-API
## Pilihan 
- [x] Crack Massal
- [x] Crack Publik
- [x] Crack Email
- [x] Crack dari file
- [x] Cek Hasil Crack

<h5 align="left">Hasil Crack:</h5>

<img src="https://raw.githubusercontent.com/MR-X-HADI/Multi-fb/main/hasil%20crack.JPG" width=50% height=50%>


![Mengetik SVG](https://readme-typing-svg.herokuapp.com?lines=gunakan+dengan-baik....!+) 
<h3 align="left">Klik Dibawah Sini Untuk informasi Contact:</h3>

[![](https://img.shields.io/badge/Github-black?logo=Github&logoColor=black&labelColor=white)](https://github.com/MR-X-HADI)
[![](https://img.shields.io/badge/Facebook-blue?logo=Facebook&logoColor=blue&labelColor=white)](https://www.facebook.com/profile.php?id=100054222010368)
[![](https://img.shields.io/badge/Whatsapp-CHAT-red?logo=Whatsapp&logoColor=Brightgreen&labelColor=white)](https://wa.me/6285362211672?text=Assalamualikum+bang+hadi)
